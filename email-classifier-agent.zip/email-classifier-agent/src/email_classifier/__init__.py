"""Email classification agent."""

from .agent import EmailClassifierAgent
from .models import Category, Classification, Email, Priority

__all__ = ["EmailClassifierAgent", "Email", "Classification", "Category", "Priority"]

