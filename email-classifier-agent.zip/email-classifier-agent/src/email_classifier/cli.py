from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

from .agent import EmailClassifierAgent
from .models import Email
from .parsing import parse_eml


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="Classify and prioritize email")
    parser.add_argument("file", nargs="?", help="An .eml, text, or JSONL file; stdin when omitted")
    parser.add_argument("--subject", default="", help="Subject when classifying plain text")
    parser.add_argument("--sender", default="", help="Sender when classifying plain text")
    parser.add_argument(
        "--provider",
        choices=("openai", "local"),
        default="openai",
        help="Classification provider (default: openai; use local only for offline fallback)",
    )
    parser.add_argument("--model", help="OpenAI model (or set OPENAI_MODEL)")
    parser.add_argument("--jsonl", action="store_true", help="Read JSON objects with sender/subject/body, one per line")
    return parser


def main(argv: list[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    agent = EmailClassifierAgent(args.provider, args.model)
    try:
        if args.jsonl:
            stream = Path(args.file).open(encoding="utf-8") if args.file else sys.stdin
            try:
                for line in stream:
                    if line.strip():
                        item = json.loads(line)
                        result = agent.classify(Email(**{k: item.get(k, "") for k in ("sender", "subject", "body")}))
                        print(json.dumps(result.to_dict(), ensure_ascii=False))
            finally:
                if args.file:
                    stream.close()
            return 0

        if args.file and Path(args.file).suffix.lower() == ".eml":
            email = parse_eml(args.file)
        else:
            body = Path(args.file).read_text(encoding="utf-8") if args.file else sys.stdin.read()
            email = Email(args.subject, body, args.sender)
        print(json.dumps(agent.classify(email).to_dict(), indent=2, ensure_ascii=False))
        return 0
    except (OSError, ValueError, RuntimeError, json.JSONDecodeError) as exc:
        print(f"error: {exc}", file=sys.stderr)
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
