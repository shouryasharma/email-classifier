from __future__ import annotations

from email import policy
from email.parser import BytesParser
from pathlib import Path

from .models import Email


def parse_eml(path: str | Path) -> Email:
    message = BytesParser(policy=policy.default).parsebytes(Path(path).read_bytes())
    body = message.get_body(preferencelist=("plain",))
    if body is not None:
        content = body.get_content()
    elif not message.is_multipart():
        content = message.get_content()
    else:
        content = ""
    return Email(
        sender=str(message.get("from", "")),
        subject=str(message.get("subject", "")),
        body=str(content),
    )

