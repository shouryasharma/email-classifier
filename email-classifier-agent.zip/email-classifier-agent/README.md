# Email Classifier Agent

An LLM-powered inbox-triage agent that classifies email into `urgent`, `action_required`,
`meeting`, `finance`, `support`, `personal`, `newsletter`, `promotion`, `spam`, or `other`.
It returns a priority, confidence, short summary, reasons, and explicit action items.

The agent uses an OpenAI model by default and validates every response against a strict schema.
An explicit local provider is available as a deterministic offline fallback.

## Quick start

```bash
python -m venv .venv
source .venv/bin/activate
pip install -e .
export OPENAI_API_KEY="your-key"

echo "Please approve the attached invoice by Friday." | \
  email-classifier --subject "Invoice approval"
```

Classify a real RFC 822 email:

```bash
email-classifier message.eml
```

Batch-process JSONL (each line may contain `sender`, `subject`, and `body`):

```bash
email-classifier emails.jsonl --jsonl > classifications.jsonl
```

## LLM configuration

```bash
export OPENAI_API_KEY="your-key"
email-classifier message.eml
```

## Interactive playground

The `web` directory contains a browser UI with sample emails, a classification readout,
confidence and priority indicators, extracted action items, and a raw JSON view.

```bash
cd web
cp .env.example .env.local
# Add your OPENAI_API_KEY to .env.local
npm install
npm run dev
```

Open `http://localhost:3000` and paste an email or choose one of the built-in edge cases.
The web endpoint uses the same categories, priorities, model default, prompt-safety rules,
and Structured Output contract as the Python agent.

Override the default model with `--model MODEL` or `OPENAI_MODEL`. The agent uses the Responses
API with Pydantic Structured Outputs, so categories and priorities always conform to the declared
schema. Email content is treated as untrusted data in the prompt to reduce prompt-injection risk,
and API response storage is disabled for these requests.

To classify without sending email to an external service, explicitly select the lower-accuracy
rule-based fallback:

```bash
email-classifier message.eml --provider local
```

## Output

```json
{
  "category": "finance",
  "priority": "medium",
  "confidence": 0.94,
  "summary": "Approval requested for an attached invoice by Friday.",
  "reasons": ["The sender explicitly requests invoice approval by a deadline."],
  "action_items": ["Please approve the attached invoice by Friday."],
  "provider": "openai"
}
```

## Test

```bash
python -m pytest
```

The tests use the explicit local provider, so they do not spend API credits. Add integration tests
with a test API key if you want to validate the configured model in CI.
