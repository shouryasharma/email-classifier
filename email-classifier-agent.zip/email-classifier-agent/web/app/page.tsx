'use client';

import { FormEvent, useMemo, useState } from 'react';

type Classification = { category:string; priority:'high'|'medium'|'low'; confidence:number; summary:string; reasons:string[]; action_items:string[]; provider:string; model:string };

const samples = [
  { label:'Urgent incident', sender:'alerts@acme.dev', subject:'Production checkout is failing', body:'We are seeing a 38% payment failure rate in production. Please investigate immediately and post an update within 30 minutes.' },
  { label:'Ambiguous request', sender:'maya@northstar.co', subject:'A thought for next week', body:'Could you take a look at the revised launch brief when you have a moment? It would be useful to discuss it before our planning session next Thursday.' },
  { label:'Newsletter', sender:'digest@designweekly.com', subject:'Design Weekly — issue 214', body:'This week: better empty states, five useful typefaces, and an interview with a product designer. Manage preferences or unsubscribe.' },
  { label:'Suspicious message', sender:'security-team@account-check.example', subject:'Verify your account immediately', body:'Your mailbox will be suspended today. Reply with your password to keep access active. Act now.' },
];

const categoryLabels:Record<string,string> = { urgent:'Urgent', action_required:'Action required', meeting:'Meeting', finance:'Finance', support:'Support', personal:'Personal', newsletter:'Newsletter', promotion:'Promotion', spam:'Spam', other:'Other' };

export default function Home() {
  const [sender,setSender] = useState(samples[1].sender);
  const [subject,setSubject] = useState(samples[1].subject);
  const [body,setBody] = useState(samples[1].body);
  const [result,setResult] = useState<Classification|null>(null);
  const [loading,setLoading] = useState(false);
  const [error,setError] = useState('');
  const [showJson,setShowJson] = useState(false);
  const wordCount = useMemo(() => body.trim().split(/\s+/).filter(Boolean).length,[body]);

  function loadSample(index:number) { const sample=samples[index]; setSender(sample.sender); setSubject(sample.subject); setBody(sample.body); setResult(null); setError(''); }
  async function classify(event:FormEvent) {
    event.preventDefault(); setLoading(true); setError(''); setResult(null);
    try {
      const response=await fetch('/api/classify',{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify({sender,subject,body})});
      const payload=await response.json(); if(!response.ok) throw new Error(payload.error||'Classification failed'); setResult(payload);
    } catch(caught) { setError(caught instanceof Error?caught.message:'Classification failed'); } finally { setLoading(false); }
  }

  return <main className="shell">
    <header className="topbar"><div className="brand"><span className="brand-mark">M</span><span>Mailroom</span><span className="beta">LAB</span></div><div className="status"><span/> LLM playground</div></header>
    <section className="intro"><p className="eyebrow">INBOX INTELLIGENCE PLAYGROUND</p><h1>What is this email<br/><em>really</em> asking?</h1><p className="lede">Paste a message, run the classifier, and inspect the model&apos;s reasoning. Try the edge cases—the interesting failures live there.</p></section>
    <section className="sample-strip" aria-label="Sample emails"><span className="sample-label">TRY A SAMPLE</span>{samples.map((sample,index)=><button type="button" key={sample.label} onClick={()=>loadSample(index)}>{sample.label}</button>)}</section>
    <div className="workspace">
      <form className="composer panel" onSubmit={classify}>
        <div className="panel-heading"><div><span className="step">01</span><h2>Email input</h2></div><button type="button" className="clear" onClick={()=>{setSender('');setSubject('');setBody('');setResult(null)}}>Clear</button></div>
        <label><span>FROM</span><input value={sender} onChange={e=>setSender(e.target.value)} placeholder="sender@example.com"/></label>
        <label><span>SUBJECT</span><input value={subject} onChange={e=>setSubject(e.target.value)} placeholder="Email subject"/></label>
        <label className="body-field"><span>MESSAGE</span><textarea value={body} onChange={e=>setBody(e.target.value)} placeholder="Paste the email body…" required/><small>{wordCount} words</small></label>
        <button className="classify" disabled={loading||!body.trim()}><span>{loading?'Reading between the lines…':'Classify email'}</span><b aria-hidden="true">↗</b></button>
        <p className="privacy">Email content is sent to the configured OpenAI model for classification.</p>
      </form>
      <section className="results panel" aria-live="polite">
        <div className="panel-heading"><div><span className="step">02</span><h2>Model readout</h2></div>{result&&<button type="button" className="clear" onClick={()=>setShowJson(!showJson)}>{showJson?'Summary':'{ } JSON'}</button>}</div>
        {error?<div className="error-state"><strong>Couldn&apos;t classify this email</strong><p>{error}</p><small>Add OPENAI_API_KEY to web/.env.local, then restart the server.</small></div>
        :loading?<div className="loading-state"><div className="scanner"/><p>Looking for intent, urgency, and explicit asks…</p></div>
        :!result?<div className="empty-state"><div className="radar"><i/><i/><span>?</span></div><h3>Ready when you are</h3><p>The model&apos;s category, confidence, summary, and extracted actions will appear here.</p></div>
        :showJson?<pre className="json-view">{JSON.stringify(result,null,2)}</pre>
        :<div className="readout"><div className="verdict"><div><span className={`priority ${result.priority}`}>{result.priority} priority</span><h3>{categoryLabels[result.category]||result.category}</h3></div><div className="confidence"><strong>{Math.round(result.confidence*100)}%</strong><span>confidence</span></div></div><div className="meter"><span style={{width:`${result.confidence*100}%`}}/></div><article className="summary"><span>IN ONE LINE</span><p>{result.summary}</p></article><article><span>WHY THIS LABEL</span><ul>{result.reasons.map(reason=><li key={reason}>{reason}</li>)}</ul></article><article><span>ACTION ITEMS</span>{result.action_items.length?<ul>{result.action_items.map(item=><li key={item}>{item}</li>)}</ul>:<p className="muted">No explicit action requested.</p>}</article><footer><span>Provider: {result.provider}</span><span>Model: {result.model}</span></footer></div>}
      </section>
    </div>
  </main>;
}
