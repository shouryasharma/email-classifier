from __future__ import annotations

from dataclasses import asdict, dataclass, field
from enum import Enum
from typing import Any


class Category(str, Enum):
    URGENT = "urgent"
    ACTION_REQUIRED = "action_required"
    MEETING = "meeting"
    FINANCE = "finance"
    SUPPORT = "support"
    PERSONAL = "personal"
    NEWSLETTER = "newsletter"
    PROMOTION = "promotion"
    SPAM = "spam"
    OTHER = "other"


class Priority(str, Enum):
    HIGH = "high"
    MEDIUM = "medium"
    LOW = "low"


@dataclass(frozen=True)
class Email:
    subject: str = ""
    body: str = ""
    sender: str = ""

    def __post_init__(self) -> None:
        if not any((self.subject.strip(), self.body.strip(), self.sender.strip())):
            raise ValueError("email must contain a sender, subject, or body")


@dataclass(frozen=True)
class Classification:
    category: Category
    priority: Priority
    confidence: float
    summary: str
    reasons: list[str] = field(default_factory=list)
    action_items: list[str] = field(default_factory=list)
    provider: str = "local"

    def __post_init__(self) -> None:
        if not 0 <= self.confidence <= 1:
            raise ValueError("confidence must be between 0 and 1")

    def to_dict(self) -> dict[str, Any]:
        result = asdict(self)
        result["category"] = self.category.value
        result["priority"] = self.priority.value
        result["confidence"] = round(self.confidence, 3)
        return result

