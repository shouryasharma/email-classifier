from email_classifier import Category, Email, EmailClassifierAgent, Priority


agent = EmailClassifierAgent(provider="local")


def test_openai_is_default_provider():
    assert EmailClassifierAgent().provider == "openai"


def test_urgent_action_email():
    result = agent.classify(Email(subject="URGENT: Production outage", body="Please investigate immediately."))
    assert result.category is Category.URGENT
    assert result.priority is Priority.HIGH
    assert result.confidence > 0.7
    assert result.action_items == ["Please investigate immediately."]


def test_invoice_email():
    result = agent.classify(Email(subject="Invoice 1042", body="Payment of $219.00 is due next week."))
    assert result.category is Category.FINANCE
    assert result.priority is Priority.MEDIUM


def test_newsletter_is_low_priority():
    result = agent.classify(Email(subject="Weekly engineering digest", body="News and links. Unsubscribe here."))
    assert result.category is Category.NEWSLETTER
    assert result.priority is Priority.LOW


def test_empty_email_is_rejected():
    try:
        Email()
    except ValueError as exc:
        assert "must contain" in str(exc)
    else:
        raise AssertionError("empty email should fail")
