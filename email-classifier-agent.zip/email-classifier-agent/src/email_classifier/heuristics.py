from __future__ import annotations

import re
from collections import defaultdict

from .models import Category, Classification, Email, Priority


RULES: dict[Category, tuple[str, ...]] = {
    Category.URGENT: ("urgent", "asap", "immediately", "critical", "outage", "breach", "past due"),
    Category.ACTION_REQUIRED: ("action required", "please review", "please approve", "respond by", "deadline", "sign", "complete"),
    Category.MEETING: ("meeting", "calendar", "invite", "schedule", "reschedule", "zoom", "teams call"),
    Category.FINANCE: ("invoice", "receipt", "payment", "refund", "expense", "billing", "purchase order"),
    Category.SUPPORT: ("support", "help", "issue", "error", "not working", "ticket", "unable to"),
    Category.NEWSLETTER: ("newsletter", "digest", "unsubscribe", "weekly update", "view in browser"),
    Category.PROMOTION: ("sale", "discount", "offer", "coupon", "% off", "limited time", "shop now"),
    Category.SPAM: ("wire transfer", "gift card", "claim your prize", "winner", "bitcoin", "act now", "verify your account"),
    Category.PERSONAL: ("birthday", "dinner", "family", "catch up", "vacation", "photos"),
}

HIGH_PRIORITY = {Category.URGENT, Category.SPAM}
MEDIUM_PRIORITY = {Category.ACTION_REQUIRED, Category.MEETING, Category.FINANCE, Category.SUPPORT}


def _contains(text: str, phrase: str) -> bool:
    return re.search(r"(?<!\w)" + re.escape(phrase) + r"(?!\w)", text) is not None


def classify_locally(email: Email) -> Classification:
    text = f"{email.subject}\n{email.body}".lower()
    scores: dict[Category, float] = defaultdict(float)
    matches: dict[Category, list[str]] = defaultdict(list)

    for category, phrases in RULES.items():
        for phrase in phrases:
            if _contains(text, phrase):
                # Subject signals carry more intent than body boilerplate.
                weight = 2.0 if _contains(email.subject.lower(), phrase) else 1.0
                scores[category] += weight
                matches[category].append(phrase)

    # Strong structural signals.
    if re.search(r"\b(mon|tue|wed|thu|fri)(day)?\b.*\b\d{1,2}(:\d{2})?\s?(am|pm)\b", text):
        scores[Category.MEETING] += 2
        matches[Category.MEETING].append("date/time")
    if re.search(r"\b[$€£]\s?\d|\b\d+[.,]\d{2}\b", text):
        scores[Category.FINANCE] += 1.5
        matches[Category.FINANCE].append("amount")
    if re.search(r"\b(today|within \d+ hours?|eod)\b", text):
        scores[Category.URGENT] += 1
        matches[Category.URGENT].append("time pressure")

    if not scores:
        category = Category.OTHER
        confidence = 0.45
        reasons = ["No strong category signals found"]
    else:
        ranked = sorted(scores.items(), key=lambda item: (-item[1], item[0].value))
        category, best_score = ranked[0]
        runner_up = ranked[1][1] if len(ranked) > 1 else 0
        margin = best_score - runner_up
        confidence = min(0.96, 0.58 + best_score * 0.07 + margin * 0.04)
        reasons = [f"Matched: {', '.join(matches[category][:4])}"]

    if category in HIGH_PRIORITY or scores.get(Category.URGENT, 0) >= 2:
        priority = Priority.HIGH
    elif category in MEDIUM_PRIORITY:
        priority = Priority.MEDIUM
    else:
        priority = Priority.LOW

    body_text = re.sub(r"\s+", " ", email.body).strip()
    summary_source = email.subject.strip() or body_text or f"Message from {email.sender}"
    summary = summary_source[:157] + ("..." if len(summary_source) > 160 else "")
    action_items = _extract_actions(email.body)
    return Classification(category, priority, confidence, summary, reasons, action_items, "local")


def _extract_actions(body: str) -> list[str]:
    sentences = re.split(r"(?<=[.!?])\s+|\n+", body.strip())
    markers = ("please ", "can you ", "could you ", "action required", "need you to", "respond by")
    actions = [s.strip() for s in sentences if s.strip() and any(m in s.lower() for m in markers)]
    return actions[:3]

