from email_classifier.parsing import parse_eml


def test_parse_eml(tmp_path):
    path = tmp_path / "message.eml"
    path.write_text("From: Alex <alex@example.com>\nSubject: Project meeting\n\nCan we meet Tuesday at 2pm?\n")
    email = parse_eml(path)
    assert "alex@example.com" in email.sender
    assert email.subject == "Project meeting"
    assert "Tuesday" in email.body

